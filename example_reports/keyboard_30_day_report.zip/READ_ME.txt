DAY-WISE INVENTORY REPORT
Product: USB Keyboard
Simulation days: 30. Each row is one day of simulation run 1.
Daily counts are whole units. Money is PKR with two decimal places.
Daily fill rate = units sold / daily demand. Zero demand is shown as 100% by convention.
Average closing stock to date = mean of closing stock from day 1 through that row's day.
Stock averages are rounded to the nearest whole unit for display and export (.5 rounds up).
Internal stock averages retain full precision for simulation calculations and costs.
Configured mean demand: 2 units/day.
Expected demand over 30 days: 60 units.
Actual demand is random and can differ from this expectation.
Daily revenue = units sold * selling price.
Daily holding cost = closing stock * holding cost per unit per day.
Daily ordering cost = orders placed that day * fixed order fee (not a mean fee).
Policy cost = holding + ordering + shortage penalty.
Modeled profit = revenue - cost of units sold - policy cost. This is not cash flow.
The run summary describes this same daily path. Dashboard/optimization means describe 100 separate runs.
Optional advanced files contain explicitly labelled per-run totals and confidence intervals.
